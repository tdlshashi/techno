<!DOCTYPE html>
<?php
session_start();
if(!isset($_SESSION["coupon"]))
{
	header("location:technosphere.php");
}

$dbhost="127.0.0.1";
$dbname="technosphere";
$dbuser="root";
$dbpass="";
$connection=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
if(mysqli_connect_errno()){
	die("database connection failed : ".mysqli_connect_error()."(" .mysqli_connect_errno().")");
}
if(isset($_POST['invalidate']))
{
	$reg_id=$_POST['reg_id'];
	 echo '<script type="javascript">';
	echo 'if(confirm(You really want to invalidate the coupon, Once it is invalidated you would not get lunch.))';
	echo '{';
	 $reg_id=$_POST['reg_id']; 
	 $query = "update participant set activated=0 where reg_id='{$reg_id}';";
	 $result = mysqli_query($connection,$query);
	 if(mysqli_affected_rows($connection)>0)
	 {
		 session_destroy();
		 echo "Invalidated";
		 
	 }
					
			echo '}';

echo '</script>';
}
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta http-equiv="refresh" content="20">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
<title>Technosphere 2k16</title> 
 <!-- CSS  -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
 <link href="css/materialize.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>
 <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
 <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
 <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script><script src="js/materialize.min.js">
 </script><script src="js/init.js"></script><style>th,td{border-right:1px solid black;}</style></head>
 <body>
 <nav style="background-color:#3498db"><div class="nav-wrapper">
 <a id="logo-container" href="http://www.ritquantum.com" class="waves-effect waves-light brand-logo white-text center" style="color:#16a085;	opacity:0.9;text-shadow: 2px 2px 6px rgba(0,0,0,0.2),3px 5px 3px rgba(255,255,255,0.3);"><b>&nbsp;&nbsp;&nbsp;&nbsp;Technosphere 2k16&nbsp;&nbsp;</b></a></div></nav>
 <div class="container">
 <div class="section center">
 <div class="row">
 <div class="col s12" style="border:2px solid teal">
 <div class="progress" style="width:100%;margin-left:auto;margin-right:auto">
 <div class="determinate" style="width: 100%;background-color:#3498db;opacity:0.5">
 </div>
 </div>
 <h5 class="center red-text light"><b>Food Coupon</b></h5>
  <div class="progress" style="width:100%;margin-left:auto;margin-right:auto">
 <div class="determinate" style="width: 100%;background-color:#3498db;opacity:0.5"></div>
 </div>
<h3 class="center teal-text"><i class="fa fa-cutlery fa-2x"></i>
</h3>
<?php

if(isset($_GET['fname'])&&$_GET['activated']==1)
{
	?>
 <div class="col s2" style="height:50px"></div>
 <div class="col s8" style="text-align:justify">
 <br>Dear, <?php echo $_GET['fname']?> enjoy the Lunch.<br><br>
 <p class="center"><b></b></p>
 </div>
 <div class="col s2" style="height:50px"></div>
 <div class="row">
 <table class="striped col s12" style="border:1px solid grey">
 <thead>
 <tr>
 <th data-field="name" style="border-left:0px solid black;">
 &nbsp;reg_id</th>
 <th data-field="part_num">first_name</th>
 <th data-field="fee">&nbsp;last_name</th>
 <th data-field="part_num">event_name</th>
 </tr>
 </thead>
 <tbody>
 <tr>
 <td style="border-left:0px solid black;">&nbsp;&nbsp;<?php echo $_GET['reg_id']?></td>
 <td>&nbsp;&nbsp;&nbsp;<?php echo $_GET['fname']?></td>
 <td>&nbsp;&nbsp;&nbsp;<?php echo $_GET['lname']?></td>
 <td>&nbsp;&nbsp;<?php echo $_GET['event_name']?></td>
 </tr>
 </tbody>
 </table>
 </div>
 </br>
 <form method="post" action="coupon.php">
 <input type="hidden" name="reg_id" value="<?php echo $_GET['reg_id'] ?>">
 <input type="hidden" name="fname" value="<?php echo $_GET['fname'] ?>">
 <input type="hidden" name="lname" value="<?php echo $_GET['lname'] ?>">
 <input type="hidden" name="event_name" value="<?php echo $_GET['event_name'] ?>">
 <button class="btn waves-effect waves-light center" name="invalidate" type="button" id="invalidate">Invalidate Coupon.</button><br>
 <div class="col s4" style="height:10px"></div>
 <button class=" col s4 btn waves-effect waves-light center" name="invalidate" type="submit" style="display:none" id="cinvalidate">Confirm Invalidate.</button><br><br/>
 <div class="col s4" style="height:10px"></div>
 </form>
 <p class="col s12 red-text">
 * Please don't try to invalidate your coupon you will not get the benefits of food.
 </p>
 <?php
}
else
{
	?>
	<div class="col s4" style="height:50px"></div>
 <div class="col s4" style="text-align:justify">
 <br>Sorry, your Coupon is expired.<br><br>
 <p class="center"><b></b></p>
 </div>
 <div class="col s4" style="height:50px"></div>
 <?php
}
?>
 <div class="progress" style="width:100%;margin-left:auto;margin-right:auto">
 <div class="determinate" style="width: 100%;background-color:#3498db;opacity:0.5">
 </div>
 </div>
 <div class="center"><b>Thanks & Regards,</b>
 <br>
 <span class="teal-text">Technosphere 2k16 team.</span>
 </div>
  <br>
 </div>
 </div>
 </div>
 </div>
 <script>
 $("#invalidate").click(function()
 {
	 var prn = prompt("Volunteer ID:", "");
    if (prn != null) 
	{
		if(prn==1203036||prn==1203099)
		{
       $("#invalidate").css("display","none");
	   $("#cinvalidate").css("display","block");
    }
	} 
	else
	{
		alert("Invalid Volunteer ID");
	}
 });
 </script>
 </body></html>