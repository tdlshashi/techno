<!DOCTYPE html>
<?php
$dbhost="127.0.0.1";
$dbname="technosphere";
$dbuser="root";
$dbpass="";
$connection=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
if(mysqli_connect_errno()){
	die("database connection failed : ".mysqli_connect_error()."(" .mysqli_connect_errno().")");
}
if(isset($_POST['submit']))
{
	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$event_name=$_POST['event_name'];	
	$activated=1;
$query = "INSERT INTO participant(fname,lname,event_name,activated) VALUES('{$fname}','{$lname}','{$event_name}','{$activated}');";
		$result = mysqli_query($connection,$query);
		if($result){
		header("location:receipt.php?fname=$fname&lname=$lname&event_name=$event_name");
		}
	
}
?>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>Technosphere 2k16</title>
  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
   <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
 <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.min.js"></script>
  <script src="js/init.js"></script>
<style>
body{
 background-color:#ececec;
}</style>
  </head>
<body>
<div class="navbar-fixed" style="z-index:1200">
  <nav role="navigation" style="background-color:#3498db">
    <div class="nav-wrapper container" >
      <a id="logo-container" href="#" class="waves-effect waves-light brand-logo white-text center" style="color:#16a085;	
opacity:0.9;
text-shadow: 2px 2px 6px rgba(0,0,0,0.2),
                 3px 5px 3px rgba(255,255,255,0.3);"><b>&nbsp;&nbsp;Technosphere 2k16&nbsp;&nbsp;</b></a>
    </div>
  </nav>
  </div>
  <div class="container">
    <div class="section">
 <div class="row center">
 
    <form class="col s12 center hoverable z-depth-1" method="post" action="volunteer.php" style="padding-right:20px;padding-left:20px;background-color:white">
	</br>
      <div class="row">
        <div class="input-field col s12 ">
          
          <input id="icon_prefix" required type="text" name="fname" class="validate">
          <label for="icon_prefix">First Name</label>
        </div>
		
		</div>
		 <div class="row">
        <div class="input-field col s12 ">
          <input id="icon_prefix" required type="text" name="lname" class="validate">
          <label for="icon_prefix"> Last Name</label>
        </div>
		</div>
			 <div class="row">
	<div class="input-field col s12">
    <select id="event_name" name="event_name" required>
      <option value="" disabled selected>Choose your option</option>
      <option value="Technohunt">Technohunt</option>
      <option value="MagicofLogic">Magic of Logic</option>
      <option value="TheInnovators">The Innovators</option>
	  <option value="Campaign">Campaign</option>
	  <option value="Dota2">Dota 2</option>
	  <option value="COC">Clash of Clans</option>
	  <option value="CounterStrike">Counter Strike</option>
	  <option value="Nfs">Nfs</option>
	  <option value="BoxCricket">Box Cricket</option>
	  <option value="RingFootball">Ring Football</option>
	  <option value="Workshop">Workshop</option>
    </select> 
    <label for="icon_prefix"><b>Event Name</b></label>
  </div>
		</div>

		<br>
	
		<button class="btn waves-effect waves-light center" type="submit" name="submit">Submit
  </button>
  <br>
		</br>
    </form>
  </div>
    </div>
  </div>
  <script>
  $(document).ready(function() {
    $('select').material_select();
  });
  </script>
  </body>
</html>