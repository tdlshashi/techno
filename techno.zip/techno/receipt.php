<!DOCTYPE html>
<?php
$dbhost="127.0.0.1";
$dbname="technosphere";
$dbuser="root";
$dbpass="";
$connection=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
if(mysqli_connect_errno()){
	die("database connection failed : ".mysqli_connect_error()."(" .mysqli_connect_errno().")");
}
if(isset($_GET['gen_id']))
{
	$fname=$_GET['fname'];
	$lname=$_GET['lname'];
	$event_name=$_GET['event_name'];	
$query = "select reg_id,fname,lname,event_name from participant where fname='{$fname}' AND lname='{$lname}' AND event_name='{$event_name}' order by reg_id DESC LIMIT 1";
		$result = mysqli_query($connection,$query);
		$row = mysqli_fetch_assoc($result);
}
?>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>Quantum 2k16</title>

  <!-- CSS  -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
   <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
 <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.min.js"></script>
  <script src="js/init.js"></script>
<style>
body{
 background-color:#ececec;
}
.event li
{
    list-style-type:disc;
}
.subevent li
{
    list-style-type:square;
}
.hov:hover .hov-li
{
color:#3498db;
background-color:#ecf0f1;
}
.hov , .hov-li
{
background-color:#ecf0f1;
}
.image
		{
		border:8px solid lavender;
		transition:0.7s;
		}
		.image:hover
		{
		border:1px solid #3498db;
		transition:0.7s;
		}
</style>
  </head>
<body>
<div class="navbar-fixed" style="z-index:1200">
  <nav role="navigation" style="background-color:#3498db">
    <div class="nav-wrapper container" >
      <a id="logo-container" href="#" class="waves-effect waves-light brand-logo white-text center" style="color:#16a085;	
opacity:0.9;
text-shadow: 2px 2px 6px rgba(0,0,0,0.2),
                 3px 5px 3px rgba(255,255,255,0.3);"><b>&nbsp;&nbsp;Technosphere 2k16&nbsp;&nbsp;</b></a>
    </div>
  </nav>
  </div>


  <div class="container">
    <div class="section">
 <div class="row">
<br>
<div class="col s12">
 <?php
 if(!isset($row["reg_id"]))
 {
?>
 <h4 class="col s12" style="font-family:Times New Roman, Times, serif;font-size:30px;">Hello, <b><?php if(isset($_GET['fname']))echo $_GET['fname']; else echo $row["fname"]?>&nbsp;<?php if(isset($_GET['lname']))echo $_GET['lname']; else echo $row["lname"]?></b> you are successfully registered for <b><?php if(isset($_GET['event_name']))echo $_GET['event_name']; else echo $row["event_name"]?></b></h4>
 <?php
 }
 ?>
<div class="hoverable center">
<h3><?php if(isset($row["reg_id"]))echo '<br>hello <b>'.$row["fname"].'</b>,<br><h2><span class="teal-text">'. $row["reg_id"].'</span></h2><br>';?></b></h3>
</div>
</div>

</div>   
 <form method="get" class="center" action="receipt.php">
 <input type="hidden" name="lname" value=<?php echo $_GET['lname']?>>
  <input type="hidden" name="fname" value=<?php echo $_GET['fname']?>>
   <input type="hidden" name="event_name" value=<?php echo $_GET['event_name']?>>
<?php 
if(!isset($row["reg_id"]))
{
?>
	 <button type="submit" class="btn waves-effect waves-light center" name="gen_id">Generate ID</button>
<?php
}
?>
 </form><br>
 <br>
 <div class="row">
 <div class="col s2" style="height:20px"></div>
 <div class="col s8 center"><a href="volunteer.php"><button type="submit"  class="btn waves-effect waves-light center" name="gen_id">Admin Panel</button></a></div>
  <div class="col s2" style="height:20px"></div>
  </div>
   </div>
  </div>
  </body>
</html>