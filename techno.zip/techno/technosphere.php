<!DOCTYPE html>
<?php
session_start();
error_reporting(0);
$dbhost="127.0.0.1";
$dbname="technosphere";
$dbuser="root";
$dbpass="";
$connection=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
if(mysqli_connect_errno())
{
	die("database connection failed : ".mysqli_connect_error()."(" .mysqli_connect_errno().")");
}
if(isset($_POST['submit']))
{
	$reg_id=$_POST['reg_id'];
	$fname=$_POST['fname'];
	$query = "select reg_id,fname,lname,event_name,activated from participant where reg_id='{$reg_id}';";
		$result = mysqli_query($connection,$query);
}
?>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>Quantum 2k16</title>

  <!-- CSS  -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
   <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
 <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.min.js"></script>
  <script src="js/init.js"></script>
<style>
body{
 background-color:#ececec;
}
.event li
{
    list-style-type:disc;
}
.subevent li
{
    list-style-type:square;
}
.hov:hover .hov-li
{
color:#3498db;
background-color:#ecf0f1;
}
.hov , .hov-li
{
background-color:#ecf0f1;
}
.image
		{
		border:8px solid lavender;
		transition:0.7s;
		}
		.image:hover
		{
		border:1px solid #3498db;
		transition:0.7s;
		}
</style>
  </head>
<body>
<div class="page" id="page" style="display:none;">
<div class="navbar-fixed" style="z-index:1200">
  <nav role="navigation" style="background-color:#3498db">
    <div class="nav-wrapper container" >
      <a id="logo-container" href="#" class="waves-effect waves-light brand-logo white-text center" style="color:#16a085;	
opacity:0.9;
text-shadow: 2px 2px 6px rgba(0,0,0,0.2),
                 3px 5px 3px rgba(255,255,255,0.3);"><b>&nbsp;&nbsp;Technosphere 2k16&nbsp;&nbsp;</b></a>
    </div>
  </nav>
  </div>


  <div class="container">
    <div class="section">
 <div class="row center">
    <form class="col s12 center hoverable z-depth-1" method="post" action="technosphere.php" style="padding-right:20px;padding-left:20px;background-color:white">
	</br>
      <div class="row">
        <div class="input-field col s12 ">
          <i class="fa fa-pencil prefix"></i>
          <input id="icon_prefix" required type="text" name="reg_id" class="validate">
          <label for="icon_prefix"> Registration ID</label>
        </div>
		
		</div>
		 <div class="row">
        <div class="input-field col s12 ">
          <i class="material-icons prefix">account_circle</i>
          <input id="icon_prefix" required type="text" name="fname" class="validate">
          <label for="icon_prefix"> First name</label>
        </div>
		</div>
<div class="result">
	<?php
	if(mysqli_num_rows($result)==0)
		{
		if(isset($_POST['fname']))
			echo "Invalid registration id.";
		}
		else
		{
			$row = mysqli_fetch_assoc($result);
			if($row["fname"]==$fname)
			{
				$reg_id=$row["reg_id"];
				$fname=$row["fname"];
				$lname=$row["lname"];
				$event_name=$row["event_name"];
				$activated=$row["activated"];
				$_SESSION["coupon"] = "coupon";
				header("location:coupon.php?reg_id=$reg_id&fname=$fname&lname=$lname&event_name=$event_name&activated=$activated");
			}
			else
			{
				echo "Invalid Registration Id or first name";
			}
		}	
		?>
</div>
		<br>
	
		<button class="btn waves-effect waves-light center" type="submit" name="submit">Get Coupon
  </button>
  <br>
		</br>
    </form>
  </div>
    </div>
  </div>
    </div>
	
<script>
  $('.modal-trigger').leanModal({
      dismissible: false, 
      opacity: 0.8, 
      in_duration: 300, 
      out_duration: 200, 
    }
  );
  $('.button-collapse').sideNav({
      edge: 'left', 
      closeOnClick: true 
    }
  );
$(document).ready(function(){
$("#page").fadeIn(1000);
})
  $(document).ready(function() {
    $('select').material_select();
  });
</script>
  </body>
</html>