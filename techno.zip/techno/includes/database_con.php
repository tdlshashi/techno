<?php
$dbhost="127.0.0.1";
$dbname="quantum";
$dbuser="root";
$dbpass="";
$connection=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
if(mysqli_connect_errno()){
	die("database connection failed : ".mysqli_connect_error()."(" .mysqli_connect_errno().")");
}

?>