-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2016 at 02:57 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `technosphere`
--

-- --------------------------------------------------------

--
-- Table structure for table `participant`
--

CREATE TABLE IF NOT EXISTS `participant` (
  `reg_id` int(4) NOT NULL AUTO_INCREMENT,
  `fname` varchar(254) NOT NULL,
  `lname` varchar(254) NOT NULL,
  `event_name` varchar(254) NOT NULL,
  `activated` tinyint(1) NOT NULL,
  PRIMARY KEY (`reg_id`),
  UNIQUE KEY `reg_id` (`reg_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `participant`
--

INSERT INTO `participant` (`reg_id`, `fname`, `lname`, `event_name`, `activated`) VALUES
(1, 'shubham', 'pawale', 'Technohunt', 1),
(2, 'shashikant', 'ghangare', 'TheInnovators', 1),
(3, 'shashikant', 'ghangare', 'COC', 1),
(4, 'abhinav', 'chavan', 'MagicofLogic', 1),
(5, 'akshay', 'jadhav', 'Dota2', 1),
(6, 'abhishek', 'meshram', 'MagicofLogic', 1),
(7, 'ajinkya', 'sakhare', 'CounterStrike', 1),
(8, 'suraj', 'varkad', 'Campaign', 1),
(9, 'avinash', 'jadhav', 'Dota2', 1),
(10, 'suraj', 'shedge', 'Technohunt', 1),
(11, 'kunal', 'sonawane', 'Campaign', 0),
(12, 'vaibhav', 'maske', 'MagicofLogic', 0),
(13, 'asmita', 'hankare', 'COC', 0),
(14, 'abhinav', 'chavan', 'MagicofLogic', 0),
(15, 'shubham', 'pawale', 'MagicofLogic', 0),
(16, 'amol', 'jagtap', 'MagicofLogic', 0),
(17, 'gaurav', 'mandrupkar', 'CounterStrike', 0),
(18, 'ajit', 'mali', 'MagicofLogic', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
